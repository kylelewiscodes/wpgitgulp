<?php
$GLOBALS['wpsdb_meta']['wp-sync-db-media-files']['version'] = '1.1.4b1';
